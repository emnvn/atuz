<?php
// Heading 
$_['heading_title'] = 'Tab Content';
?>